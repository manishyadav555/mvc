package com.mvc.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mvc.model.User;

public class UserDao 
{
	private Connection conn;
	private PreparedStatement pst;
	private String sql;
	ResultSet rs;
	
	public UserDao()throws ClassNotFoundException, IOException, SQLException
	{
		conn = MyConnection.getConnection();
	}
	public Boolean addRecord(User user)throws SQLException
	{
		sql = "select * from mvc where username=? and userpassword=?";
		pst = conn.prepareStatement(sql);
		pst.setString(1,user.getUsername());
		pst.setString(2,user.getUserpassword());
		
		rs=pst.executeQuery();
		if(rs.next()==true)
			return true;
		else
			return false;
	}

}

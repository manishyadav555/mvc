package com.mvc.dao;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class MyConnection 
{
	private MyConnection()
	{
		
	}
	private static Connection conn;
	public static Connection getConnection()throws ClassNotFoundException, IOException, SQLException
	{
		FileReader fr = new FileReader("C:\\Users\\Kritika Pal\\Desktop\\MyConnection.properties");
		Properties p = new Properties();
		p.load(fr);
		String driver = p.getProperty("driverName");
		String url = p.getProperty("url");
		String uname = p.getProperty("uname");
		String upass = p.getProperty("upass");
		if(conn==null)
		{
			Class.forName(driver);
			conn=DriverManager.getConnection(url,uname,upass);
			System.out.println("Load and Connector...");
		}
		return conn;
	}

}

package com.mvc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.dao.UserDao;
import com.mvc.model.User;

@WebServlet("/validateController")
public class ValidationController extends HttpServlet
{
	public void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException
	{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String username = req.getParameter("username");
		String password = req.getParameter("userpassword");
		
		User user = new User();
		user.setUsername(username);
		user.setUserpassword(password);
		
		try
		{
			UserDao userDao = new UserDao();
			Boolean result = userDao.addRecord(user);
			if(result==true)
			{
				RequestDispatcher rd = req.getRequestDispatcher("wel");
				rd.forward(req, res);
			}
			else
			{
				RequestDispatcher rd = req.getRequestDispatcher("err");
				rd.forward(req,res);
			}
		}catch(SQLException e)
		{
			out.println(e);
		}catch(ClassNotFoundException e)
		{
			out.println(e);
		}
		out.println("<br><br><a href='index.html'>Back</a>");
		
	}

}
